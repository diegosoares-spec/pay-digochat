document.getElementById('cadastro-form').addEventListener('submit', function(event) {
    event.preventDefault();

    const email = document.getElementById('email').value;
    const affiliateId = window.promotekit_referral;

    const stripePaymentLink = "https://buy.stripe.com/eVa00k95a8Nu30e6gbgUM05";

    let finalUrl = `${stripePaymentLink}?prefilled_email=${encodeURIComponent(email)}`;

    if (affiliateId) {
        finalUrl += `&client_reference_id=${affiliateId}`;
    }

    console.log("Redirecionando para:", finalUrl);
    window.location.href = finalUrl;
});